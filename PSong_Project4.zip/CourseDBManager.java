import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The data manager allows the user to read the courses from a file 
 * or to enter the data by hand and uses an Alert to print out the database elements.
 * 
 * @author Philip Song
 *
 */
public class CourseDBManager implements CourseDBManagerInterface {

	final static int DEFAULT_MAX = 10;
	private CourseDBStructure courseDB;
	
	/**
	 * Default Constructor
	 */
	public CourseDBManager() {
		this(DEFAULT_MAX);
	}
	
	public CourseDBManager(int n) {
		courseDB = new CourseDBStructure(n);		
	}
	
	/**
	 * method to add course to data structure
	 */
	@Override
	public void add(String id, int crn, int credits, String roomNum, String instructor) {		
		CourseDBElement newCourse = new CourseDBElement(id, crn, credits, roomNum, instructor);
		courseDB.add(newCourse);		
	}

	@Override
	public CourseDBElement get(int crn) {
		CourseDBElement foundCourse = null;
		
		try {
			foundCourse = courseDB.get(crn);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return foundCourse;
	}

	@Override
	public void readFile(File input) throws FileNotFoundException {
		Scanner inputFile = new Scanner(input);
		String id, roomNum, instructor;
		int crn, credits;
		
		while (inputFile.hasNextLine()) {
			Scanner line = new Scanner(inputFile.nextLine());
			
			id = line.next();
			crn = line.nextInt();
			credits = line.nextInt();
			roomNum = line.next();
			instructor = line.next();
			
			this.add(id, crn, credits, roomNum, instructor);
		}
		
		inputFile.close();
	}

	@Override
	public ArrayList<String> showAll() {
		return courseDB.showAll();
	}
	
}


