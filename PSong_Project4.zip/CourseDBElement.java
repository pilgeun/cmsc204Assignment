import java.io.IOException;

/**
 * @author Philip Song
 *
 */
public class CourseDBElement implements Comparable {

	private String id, roomNum, instructor;
	private int credits, crn;
	
	public CourseDBElement() {
		id = roomNum = instructor = "";
		credits = crn = 0;
	}
	
	public CourseDBElement(String id, int crn, int credits, String roomNum, String instructor) {
		this.id = id;
		this.crn = crn;
		this.credits = credits;
		this.roomNum = roomNum;
		this.instructor = instructor;
	}
	
	/**
	 * @param c
	 * @return 1 if two courses are the exact same
	 * @return 0 if not
	 */
	public int compareTo(CourseDBElement c) {
		
		if ( (this.id == c.id)&&(this.crn == c.crn)&&(this.credits == c.credits)
				&&(this.roomNum == c.roomNum)&&(this.instructor == c.instructor) )
			return 1;
		
		return 0;
	}

	public String getID() {
		return id;
	}

	public void setID(String id) {
		this.id = id;
	}

	public String getRoomNum() {
		return roomNum;
	}

	public void setRoomNum(String roomNum) {
		this.roomNum = roomNum;
	}

	public String getInstructor() {
		return instructor;
	}

	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}

	public int getCredits() {
		return credits;
	}

	public void setCredits(int credits) {
		this.credits = credits;
	}

	public int getCRN() {
		return crn;
	}

	public void setCRN(int crn) {
		this.crn = crn;
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}


}
