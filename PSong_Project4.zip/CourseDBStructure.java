import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Map.Entry;

/**
 * implementing hash table with buckets
 * Each bucket will be an array of linked lists of CourseDBElements
 * Each CourseDBElement object will have a hash code based on the CRN
 * @author Philip Song
 * @param <T>
 *
 */
public class CourseDBStructure implements CourseDBStructureInterface {
	
	private Hashtable<Integer, LinkedList<CourseDBElement>> courses;
	private int size;
	
	/**
	 * @param n = estimated number of courses
	 * Constructor
	 */
	public CourseDBStructure(int n) {
		n = (int) Math.ceil(n/1.5);	//round up n/1.5 
		int primeNum = 7; // 4(1)+3
		int k = 2;
		
		while (primeNum < n || !isPrime(primeNum)) //finds 4k+3 prime number larger than n/1.5
		{ 
			primeNum = 4*k+3;
			k++;
		}
		
		size = primeNum;	// 7 by default
		courses = new Hashtable<>(size);
	}
	
	/**
	 * Constructor for testing purpose only
	 */
	public CourseDBStructure(String testing, int n) {
		size = n;
		courses = new Hashtable<>(size);
	}
	
	/**
	 * take a CourseDBElement object and add it to the data structure, 
	 * based on the calculated hashcode of CRN value
	 * Also updates course information
	 */
	@Override
	public void add(CourseDBElement element) {
		int hashcode = element.getCRN()%size;
		LinkedList<CourseDBElement> entry = new LinkedList<>();		
		
		if (courses.containsKey(hashcode)) 
		{
			entry = courses.get(hashcode);	
			
			for (int i = 0; i < entry.size(); i++) 
			{
				if (element.compareTo(entry.get(i)) == 1)
					return;
				
				else if (element.getCRN() == entry.get(i).getCRN()) // update course info if needed
				{
					entry.set(i, element);
					return;
				}
			}
		}
		
		entry.add(element);
		courses.put(hashcode, entry);
	}

	@Override
	public CourseDBElement get(int crn) throws IOException {
		int hashcode = crn%size;
		CourseDBElement foundCourse = null;
		
		if (courses.containsKey(hashcode)) {
			LinkedList<CourseDBElement> entry = courses.get(hashcode);
			
			for (int i = 0; i < entry.size(); i++) 
			{
				if (crn == entry.get(i).getCRN())
				{
					foundCourse = entry.get(i);
					break;
				}
			}
		}
		else
			throw new IOException("threw Exception successfuly for the course not found");
		
		return foundCourse;
	}

	@Override
	public ArrayList<String> showAll() {
		ArrayList<String> courseList = new ArrayList<>();
		LinkedList<String> tempList = new LinkedList<>();
		LinkedList<CourseDBElement> entry;
		String id, roomNum, instructor, courseInfo;
		int crn, credits;
		
		for (Entry<Integer, LinkedList<CourseDBElement>> e : courses.entrySet()) 
		{
			entry = e.getValue();
			
			for (int i = 0; i < entry.size(); i++)
			{
				id = entry.get(i).getID();
				crn = entry.get(i).getCRN();
				credits = entry.get(i).getCredits();
				instructor = entry.get(i).getInstructor();
				roomNum = entry.get(i).getRoomNum();
				
				courseInfo = "\nCourse:" +id+ " CRN:" +crn+ " Credits:" +credits+ " Instructor:" +instructor+ " Room:" +roomNum;
				tempList.addFirst(courseInfo);
	
			}
		}
		
		for (String course : tempList)
			courseList.add(course);
			
		return courseList;
	}

	@Override
	public int getTableSize() {
		return size;
	}

	/**
	 * @param n = number being tested
	 * @return if n is prime number
	 */
	public static boolean isPrime(int n) {
		
		if (n <= 1 || n%2 == 0) 
			return false;
		
		for (int i = 3; i <= Math.sqrt(n); i+=2)	// checks for odd number divisors
		{ 
			if (n%i == 0)
				return false;
		}
		
		return true;
	}
	
	public String toString(CourseDBElement course) {
		return "\nCourse:" +course.getID()+ " CRN:" +course.getCRN()+ " Credits:" +course.getCredits()+ " Instructor:" +course.getInstructor()+ " Room:" +course.getRoomNum();
		
	}
	
}
