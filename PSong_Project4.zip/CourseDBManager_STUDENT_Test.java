import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author Philip Song
 *
 */

class CourseDBManager_STUDENT_Test {
	private CourseDBManagerInterface courseDB = new CourseDBManager();
	CourseDBElement course1 = new CourseDBElement("cmsc140", 35482, 3, "online", "Najmeh A.");
	CourseDBElement course2 = new CourseDBElement("CMSC203", 46519, 4, "Online", "Farnaz Eivazi");
	
	@BeforeEach
	void setUp() throws Exception {
		courseDB = new CourseDBManager();
		courseDB.add("cmsc140", 35482, 3, "online", "Najmeh A.");
		courseDB.add("CMSC203", 46519, 4, "Online", "Farnaz Eivazi");
	}

	@AfterEach
	void tearDown() throws Exception {
		courseDB = null;
	}

	@Test
	void testAdd() {
		try {
			courseDB.add("CMSC204", 21752, 4, "distance-learning", "Dr. Thai");
		}
		catch(Exception e) {
			fail("This should not have caused an Exception");
		}
	}

	
	@Test
	void testShowAll() {
		ArrayList<String> courseList = courseDB.showAll();
		assertEquals(courseList.get(0), "\nCourse:CMSC203 CRN:46519 Credits:4 Instructor:Farnaz Eivazi Room:Online");
		assertEquals(courseList.get(1), "\nCourse:cmsc140 CRN:35482 Credits:3 Instructor:Najmeh A. Room:online");
	}

}
